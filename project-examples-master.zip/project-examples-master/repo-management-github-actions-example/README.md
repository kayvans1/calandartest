# Repo Management GitHub Actions Example

This example demonstrates how you can use GitHub Actions to automate the creation and deletion of Artifactory repositories, which correspond to feature branches that are created on GitHub.
The full description of how to set up and run this example are available on <---this blog post--->.