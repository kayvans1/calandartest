# Repo Management GitHub Actions Example

This example demonstrates how you can use GitHub Actions to automate the creation and deletion of Artifactory repositories, which correspond to feature branches that are created on GitHub.
The full description of how to set up and run this example is included in [this](https://jfrog.com/blog/automating-your-feature-branch-repository-management-with-jfrog-cli/) blog post.
