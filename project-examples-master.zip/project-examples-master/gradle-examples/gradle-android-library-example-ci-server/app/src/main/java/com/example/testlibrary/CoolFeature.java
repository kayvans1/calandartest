package com.example.testlibrary;

import java.util.Date;

public class CoolFeature {

    public Date getToday(){
        return new Date();
    }
}
