﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MsbuildExample
{
    public class MsbuildExample
    {
        public static string HelloWorld()
        {
            return "Hello world";
        }
    }
}
