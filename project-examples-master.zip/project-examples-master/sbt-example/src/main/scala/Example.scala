
object Example {
  def main(args: Array[String]) = println("Sample Scala Project")
}